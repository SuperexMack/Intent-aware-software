# ghLockedin (v1)

> “What if your laziness could cost you money?”

ghLockedin is a Web3-powered accountability system that turns consistency into a financial commitment.  
You stake ETH, commit to showing up on GitHub every day, and build a streak.  
Miss a day? You pay the price.

This is not just productivity tracking.  
This is **discipline enforced by code + money + on-chain proof.**

---

## 🎥 Demo

> ⚠️ Slight lag may be present in current build  
> Watch in 2x for better flow understanding

https://github.com/user-attachments/assets/e0667a07-feba-4ec2-95e0-75d7db2e0a62

---

## Live Concept

- Stake ETH to enter a challenge
- Commit to daily GitHub activity (streak tracking)
- Miss a day → stake gets locked & challenge resets
- Stay consistent → maintain control over your funds

---

## ⚙️ How It Works

1. User connects wallet
2. Stakes ETH into a smart contract
3. System tracks daily GitHub activity
4. Backend verifies streak consistency
5. Smart contract enforces rules:
   - Active streak → funds safe
   - Missed day → penalty / stake locked


---



## Core Idea

Traditional productivity apps:
> “Be consistent 🙂”

ghLockedin:
> “Be consistent… or lose money 💀”

It combines:
- Accountability
- Financial incentive
- On-chain transparency

---

## 🛠️ Tech Stack (v1)

- **Frontend:** Next.js
- **Backend:** Node.js,Express.js,Prisma ORM, Github Auth
- **Blockchain:** Ethereum smart contracts (Solidity)
- **Wallet Integration:** Web3 / Ethers.js
- **GitHub API:** Streak tracking system

---

## 📊 Features (v1)

- Wallet-based authentication
- ETH staking mechanism
- GitHub daily activity tracking
- Streak validation logic
- Challenge reset system
- On-chain transaction history

---

## ⚠️ Current Status

> ⚙️ This project is in **testing / v1 prototype phase**

- Demo mode currently active (reduced duration streak)
- Full 30-day challenge system will be re-enabled after testing
- Performance optimizations pending

---

## 🧪 Disclaimer

This is an experimental project built for learning + experimentation in:
- Web3 mechanics
- Behavioral incentives
- On-chain accountability systems

Use at your own risk.

---

## 🔮 Future Plans (v2)

- Smarter streak verification system
- Social challenges (compete with friends)
- Partial stake recovery system
- Anti-cheat improvements
- Better UX + real-time tracking dashboard
- DAO-based challenge pools

---


## 🧑‍💻 Built By

This is built by Mohit Sati

---

## 📌 Philosophy

> I love u Satoshi Nakamoto
