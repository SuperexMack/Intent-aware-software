import cron from "node-cron"
import {prisma} from "../PrismaLab/prisma.js"


    cron.schedule("20-50 18 3 * * *" , async()=>{
    try{
    console.log("testing")
    let allUser = await prisma.userCommitData.findMany()
    for (let i = 0; i < allUser.length; i++) {
        const account = allUser[i]
            if(account.lastCheckDate != new Date().toISOString().slice(0,10) && account.lastCheckDate != "0"){
            await prisma.userCommitData.update({
                where: { id: account.id },
                data: {lastCheckDate: "0"},
            })
        }
        }
    }

    catch(error){
        return "Something went wrong while making the cron job"
    }
    })