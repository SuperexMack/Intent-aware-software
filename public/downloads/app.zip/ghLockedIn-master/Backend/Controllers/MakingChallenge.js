import express from "express"
import {prisma} from "../PrismaLab/prisma.js"
import { authMiddleware } from "../middleware/userauthMiddleware.js"
const app = express()
const router = express.Router()


router.post("/startChallenge",authMiddleware,async(req,res)=>{
    
    try{
    let userId = req.usersId
    console.log("user id is " , userId)
    let todayDate = new Date().toISOString().slice(0,10);
    let checkUserData = await prisma.userCommitData.create({
        data:{
            lastCheckDate:todayDate,
            authorId:userId
        }
    })

    if(checkUserData){
        return res.json({msg:"Challenge Started"})
    }
    else {
        return res.json({msg:"Something went wrong while making the challenge "})
    }

    }
    catch(error){
        return res.json({msg:"Something went wrong while making the challenge "+ error})
    }
    
})

export default router