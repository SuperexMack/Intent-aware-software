import express, { json } from "express"
import dotenv from "dotenv"
import { Octokit } from "octokit"
import jwt from "jsonwebtoken"
import { prisma } from "../PrismaLab/prisma.js"
dotenv.config()
const CLIENT_ID = process.env.CLIENT_ID
const CLIENT_SECRET = process.env.CLIENT_SECRET
const JWT_SECRET = process.env.JWT_SECRET
const router = express.Router()

console.log("done")

router.get("/auth/github",async(req,res)=>{
    console.log("We are coming")
    res.redirect(
    `https://github.com/login/oauth/authorize?client_id=${CLIENT_ID}&scope=repo read:user`
  );
})

router.get("/auth/github/callback",async(req,res)=>{

  try{
    console.log("This is the callback")
    let code = req.query.code
    let token = await fetch("https://github.com/login/oauth/access_token",{
        method:"POST",
        headers:{
            "Content-Type":"application/json",
            Accept: "application/json",
        },
        body:JSON.stringify({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        code,
        })
    })

    console.log("Aandar tak")

    let access_token_getter = await token.json()
    console.log(access_token_getter)
    let access_token = access_token_getter.access_token

    const userData = await fetch("https://api.github.com/user",{
        method:"GET",
        headers:{
            Authorization: `Bearer ${access_token}`
        }
    })
    

    let allDataUser = await userData.json()
    console.log({
        githubId: allDataUser.id,
        username: allDataUser.login,
        avatar: allDataUser.avatar_url,
    })
    let userObject = {
        githubId: access_token,
        username: allDataUser.login,
        avatar: allDataUser.avatar_url,
    } 

  const octokit = new Octokit({
  auth: access_token,
});

console.log(access_token)
console.log(access_token.length)

console.log(userObject.username)

let getDate = new Date(Date.now() - 24 * 60 * 60 * 1000);

const { data } = await octokit.request('GET /user/repos', {
  since: getDate,
  headers: {
    'X-GitHub-Api-Version': '2026-03-10',
    accept:"application/vnd.github+json"
  }
})

if(data.length === 0){
  
  console.log("File not found")
  
}

const latestCommit = data;
console.log(latestCommit)


    // Checking is the user already present or not

    let checkingUser = await prisma.user.findFirst({
      where:{
        username:userObject.username
      }
    })

    if(checkingUser){
      let gettingId = checkingUser.id
      let jwtokenGen = jwt.sign({gettingId},JWT_SECRET)
      await prisma.user.update({
        where:{
          id:checkingUser.id,
        },
        data:{
          access_token:access_token
        }
      })
      res.cookie("token",jwtokenGen,{
        httpOnly:true,
        secure:false,
        sameSite:"lax",
        maxAge: 7 * 24 * 60 * 60 * 1000,
      })
      res.redirect(`http://localhost:3000/Auth`)
      return
    }

    let userCreate = await prisma.user.create({
      data:{
        username:userObject.username,
        access_token: userObject.githubId
      }
    })

    if(userCreate){
      let gettingId = userCreate.id
      let jwtokenGen = jwt.sign({gettingId},JWT_SECRET)
      console.log(jwtokenGen)
      res.cookie("token",jwtokenGen,{
        httpOnly:true,
        secure:false,
        sameSite:"lax",
        maxAge: 7 * 24 * 60 * 60 * 1000,
      })
      res.redirect(`http://localhost:3000/Auth`)
      return
    }


    

  }

  catch(error){
    return res.json({msg:"Something went wrong while creating the user " + error})
  }
  
  
})

export default router