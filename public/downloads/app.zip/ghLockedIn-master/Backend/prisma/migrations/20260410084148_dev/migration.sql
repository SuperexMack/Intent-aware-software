-- AlterTable
ALTER TABLE "user" ALTER COLUMN "access_token" SET DATA TYPE TEXT;
