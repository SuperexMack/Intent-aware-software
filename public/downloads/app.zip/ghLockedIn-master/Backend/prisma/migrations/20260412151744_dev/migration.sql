/*
  Warnings:

  - You are about to drop the column `lastCommitData` on the `userCommitData` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "userCommitData" DROP COLUMN "lastCommitData";
