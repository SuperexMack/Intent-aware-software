-- CreateTable
CREATE TABLE "userCommitData" (
    "id" TEXT NOT NULL,
    "lastCommitData" TEXT NOT NULL,
    "lastCheckDate" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "userCommitData_id_key" ON "userCommitData"("id");
