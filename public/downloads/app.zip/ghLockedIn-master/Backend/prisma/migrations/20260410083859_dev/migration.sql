/*
  Warnings:

  - Changed the type of `access_token` on the `user` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.

*/
-- AlterTable
ALTER TABLE "user" DROP COLUMN "access_token",
ADD COLUMN     "access_token" INTEGER NOT NULL;
