/*
  Warnings:

  - Added the required column `authorId` to the `userCommitData` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "userCommitData" ADD COLUMN     "authorId" TEXT NOT NULL;

-- AddForeignKey
ALTER TABLE "userCommitData" ADD CONSTRAINT "userCommitData_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
