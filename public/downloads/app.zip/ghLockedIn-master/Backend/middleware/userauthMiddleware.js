import express from "express"
import jwt from "jsonwebtoken"
import dotenv from "dotenv"
dotenv.config()
const JWT_SECRET = process.env.JWT_SECRET


export const authMiddleware = (req,res,next)=>{
    // console.log("cookies:", req.cookies);
    // console.log("cookiesdddd:", req.cookies.token);
   let checkUserIdentity = req.cookies.token
   if(!checkUserIdentity) return res.json({msg:"User is not verified"})
   try{
    const decoded = jwt.verify(checkUserIdentity,JWT_SECRET)
    console.log("decode is " , decoded.gettingId)
    const usersId = decoded.gettingId
    req.usersId = usersId
    next()
   }
   catch(error){
    return res.json({msg:"Something went wrong in the auth middleware " + error})
   }
}