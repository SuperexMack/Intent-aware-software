import express from "express"
import cors from "cors"
import LoginRouter from "./Controllers/Login.js"
import checkCommit from "./Controllers/CheckCommit.js"
import makeChallenge from "./Controllers/MakingChallenge.js"
import cookieParser from "cookie-parser"
import rateLimit from "express-rate-limit"
import "./Jobs/cron-jobs.js"

const app = express()
const PORT = 9000

const limiter = rateLimit({
	windowMs: 1 * 60 * 1000, 
	limit: 5,
	standardHeaders: 'draft-8',
	legacyHeaders: false,
	ipv6Subnet: 56,
})

app.use(limiter)


app.use(express.json());
app.use(cors({
  origin: "http://localhost:3000",
  credentials: true
}))

app.use(cookieParser())


app.use("/",LoginRouter)
app.use("/v1/userCommit",checkCommit)
app.use("/v1",makeChallenge)

app.get("/",(req,res)=>{
    return res.json({msg:"GhLockedin Welcomes You"})
})


app.listen(PORT, (req,res)=>{
    console.log(`Server is running on the port number ${PORT}`)
})