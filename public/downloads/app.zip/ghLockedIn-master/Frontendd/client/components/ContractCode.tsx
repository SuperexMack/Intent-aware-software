"use client";


import { HeroVideoDialogDemo } from "./VideoDBox";



export default function ContractCode() {
  return (
    <section className="max-w-5xl mx-auto px-6 py-24">
      <p className="font-mono text-[11px] text-[#3fb950] uppercase tracking-[0.12em] mb-4">
        How it Works
      </p>
      <h2
        className="font-serif text-white font-normal leading-[1.12] mb-4"
        style={{ fontSize: "clamp(32px, 4vw, 48px)" }}
      >
        Lets see
        <br />
        How it works
      </h2>
      <p className="text-[#768390] text-base max-w-md leading-relaxed mb-10">
        Check out the video for the working process
      </p>

      <div className="rounded-xl border border-[#1c2128] overflow-hidden">
        
        <HeroVideoDialogDemo></HeroVideoDialogDemo>
        
      </div>
    </section>
  );
}
