"use client"
import React from "react";
import {useConnect } from "wagmi";

export const WalletLogic = ()=>{
    const {connectors,connect} = useConnect()

    return(
        <>
        <div className=" p-2 space-x-6 items-center justify-center">
           {connectors.map((connector)=>(
            <button key={connector.id} className="text-white font-bold text-[30px]" onClick={()=>connect({connector})}><p className="cursor-pointer">{connector.name}</p></button>
           ))}
        </div>
        </>
    )

}