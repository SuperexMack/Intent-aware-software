import { http, createConfig} from 'wagmi'
import { mainnet} from 'wagmi/chains'
import { metaMask , injected} from 'wagmi/connectors'


export const config = createConfig({
  chains: [mainnet],
  connectors:[injected()],
	  transports: {
	    [mainnet.id]: http(),
  },
})