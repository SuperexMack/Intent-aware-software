import { NextResponse } from 'next/server'
import { NextRequest } from 'next/server'

export function proxy(request: NextRequest) {
    const token = request.cookies.get('token')?.value
    const path = request.nextUrl.pathname


    if (
        path.startsWith('/_next') ||
        path.startsWith('/favicon.ico') ||
        path.startsWith('/images')
    ) {
        return NextResponse.next()
    }


    if (path.startsWith('/startChallenge')) {
        if (!token) {
        return NextResponse.redirect(new URL('/Auth', request.url))
        }
        return NextResponse.next()
    }

    if (path.startsWith('/yourCommits')) {
        if (!token) {
        return NextResponse.redirect(new URL('/Auth', request.url))
        }
        return NextResponse.next()
    }

    
    if (path.startsWith('/Auth')) {
        if (token) {
            return NextResponse.redirect(new URL('/', request.url))
        }
        return NextResponse.next()
    }

    

    return NextResponse.next()
}

export const config = {
    matcher: ['/:path*'],
}