// SPDX-License-Identifier: Unlicense
pragma solidity ^0.8.13;

import "forge-std/Test.sol";

import "../src/Contract.sol";

contract TestContract is Test {
    Contract c;

    function setUp() public {
        c = new Contract();
    }
    

    function testIns() public {
        string memory res = c.investigateAccount(true,1776105748,"0x023bf9cb02cd01a5d68953d049e5f30cb375821e1e9417f9badef4ad2e472cfb68c832e210506028d46c2b50675da76cdaf545e483ac9bc4aefbfcf5f0c1465b1c");
        assertEq(res,"Signature is not verified","ok");
    }
}
